import {
  Alert,
  Button,
  MenuItem,
  TextField,
  Typography,
} from "@mui/material";
import { useState } from "react";
import { storage } from "../firebase";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { v4 } from "uuid";
import { dataBase } from "../firebase";
import { UserAuth } from "../context/AuthContext";
function ProductForm() {
  const [imageUpload, setImageUpload] = useState(null);
  const [imageUrl, setImageUrl] = useState("");
  const [amountInStock, setAmountInStock] = useState(0);
  const [category, setCategory] = useState("Shoes");
  const [description, setDescription] = useState("");
  const [name, setName] = useState("");
  const [price, setPrice] = useState(0);
  const [showMessage, setShowMessage] = useState("none");
  const [message, setMessage] = useState("default")
  const [type, setType] = useState("error")
  const { doc, setDoc } = UserAuth();
   
  //categories
  const categories = [
    {
      value: "Shoes",
      label: "Shoes",
    },
    {
      value: "Shirt",
      label: "Shirt",
    },
    {
      value: "Pants",
      label: "Pants",
    },
    {
      value: "Hat",
      label: "Hat",
    },
  ];
  //upload image to firebase storage
  const uploadImage = async () => {
    if (imageUpload == null) return;
    const imageRef = ref(storage, `productImages/${imageUpload.name + v4()}`);
    try {
      await uploadBytes(imageRef, imageUpload);
      getDownloadURL(imageRef).then((downloadURL) => {
       setImageUrl(downloadURL)
      });
    } catch (e) {
      alert(e.message);
    }
  };
  // validate inputs
  const validateInputs = () => {
    if(imageUpload === null )
    {
     setMessage("Please select an image to upload")
     setShowMessage("show")
     return false
    }
    else if (imageUrl.length === 0)
    {
      setMessage("Click the upload button ")
      setShowMessage("show")
      return false
     }
     else if (amountInStock < 1)
     {
       setMessage("Amount in stock must be at least 1")
       setShowMessage("show")
       return false
      }
      else if (description.length === 0)
      {
        setMessage("Description cannot be empty")
        setShowMessage("show")
        return false
       }
       else if ( name.length === 0)
       {
         setMessage("Name cannot be empty")
         setShowMessage("show")
         return false
        }
        else if (price <= 0)
        {
          setMessage("Price must be more than zero")
          setShowMessage("show")
          return false
         }
         else{
          if(showMessage === "show")
         setShowMessage("none")
         }
         return true;
}
  //add new item to store
  const AddItemToStore = async () => {
    // validate input
    if(!validateInputs()){return}
  
    // create item
    let newItem = {
      name: name,
      price: Number(price),
      amountInStock: Number(amountInStock),
      category: category,
      description: description,
      imageSrc: imageUrl
    };
    // Add the document to the collection
    try {
      await setDoc(doc(dataBase, "items", v4()), newItem);
      if(type !== "success")
      setType("success");
      setMessage(`${name} added successfully to Store`);
      setShowMessage("show")
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div
      style={{ display: "flex", justifyContent: "center" }}
    >
      <div
        className="formNewProduct"
        style={{
          display: "flex",
          flexDirection: "column",
          border: "1px solid",
          alignItems: "center",
          width: "50%",
          margin: "15px",
          padding: "10px",
        }}
      >
        <div className="header" style={{ display: "flex", justifyContent: "space-between", width:"100%" }} >
        <Typography sx={{textDecoration:"underline"}} variant="h4">Add New Product:</Typography>
        <Alert sx={{height:"50px", display:`${showMessage}`}} severity={type}>{message}</Alert>
        </div>
        <hr />
        <div
          className="mainFormSection"
          style={{
            display: "flex",
            width: "100%",
            justifyContent: "space-around",
          }}
        >
          <TextField
            onChange={(e) => {
              setName(e.target.value);
            }}
            id="productName"
            label="Name"
            variant="outlined"
          />
          <TextField
            type="number"
            onChange={(e) => {
              setPrice(e.target.value);
            }}
            id="productName"
            label="Price"
            variant="outlined"
          />
          <TextField
            type="number"
            onChange={(e) => {
              setAmountInStock(e.target.value);
            }}
            id="productName"
            label="Amount In Stock"
            variant="outlined"
          />
        </div>
        <br />
        <div
          className="imgUpload"
          style={{
            width: "100%",
            justifyContent: "space-between",
          }}
        >
          <div className="">
            <TextField
              id="outlined-select-currency"
              select
              label="Select Category"
              defaultValue={category}
              onChange={(e) => {
                setCategory(e.target.value);
              }}
              helperText="Please select your Category"
              style={{marginBottom:'5%'}}
            >
              {categories.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </TextField>
            <br />
          </div>
          <div className="">
            <TextField
              onChange={(e) => {
                setDescription(e.target.value);
              }}
              id="description"
              label="Description"
              multiline
              rows={3}
              placeholder="Enter Description here..."
              style={{marginBottom:'5%'}}
            />
          </div>
          <div style={{display:'flex',flexDirection:'column'}} className="">
          <input
            type="file"
            onChange={(e) => {
              setImageUpload(e.target.files[0]);
            }}
            accept="JPG, image,PNG"
            style={{marginBottom:'3%'}}
          />
          <Button style={{width: '70px'}} onClick={uploadImage} variant="contained"> Upload</Button>
          </div>
          
        </div>
        <br />
        <div style={{borderRadius:'20%',marginBottom: '5%',marginTop: '5%',width:'100%', border: '2px black solid'}} className="uploadProductBarrier"></div>
        <Button onClick={AddItemToStore} variant="contained">
          Add To Store
        </Button>
      </div>
   
    </div>
  );
}
export default ProductForm;
