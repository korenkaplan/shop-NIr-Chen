import React from 'react'
import AddProduct from './AddProduct'

export default function AdminPage() {
  return (
    <div>
      <AddProduct/>
    </div>
  )
}
