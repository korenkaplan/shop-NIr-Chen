import React from "react";
import Account from "./Pages/Account";
import Signin from "./Pages/Signin";
import Shop from "./Pages/Shop";
import "bootstrap/dist/css/bootstrap.min.css";
import Navbar from "./Comps/Navbar";
import Cart from "./Pages/Cart";
import Signup from "./Pages/Signup";
import AdminPage from "./AdminComps/AdminPage";
import { Route, Routes } from "react-router-dom";
import { AuthContextProvider } from "./context/AuthContext";
import { CartContextProvider } from "./context/CartContext";
import Protectedroutes from "./Comps/Protectedroutes";
function App() {
  return (
    <div className="App">
      <AuthContextProvider>
      <Navbar />
        <Routes>
          <Route path="/" element={<Signin />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/shop" element={<CartContextProvider><Shop /></CartContextProvider>} />
          <Route path="/cart" element={<CartContextProvider><Cart /></CartContextProvider>} />
          <Route  path="/admin" element={<CartContextProvider><AdminPage /></CartContextProvider>} />
          <Route
            path="/account"
            element={
              <Protectedroutes>
                <Account />
              </Protectedroutes>
            }
          />
        </Routes>
      </AuthContextProvider>
    </div>
  );
}

export default App;
