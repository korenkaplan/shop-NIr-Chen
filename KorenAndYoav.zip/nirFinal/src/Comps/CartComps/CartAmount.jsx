import React, { useState } from 'react'
import { UserAuth } from '../../context/AuthContext'
import Button from '@mui/material/Button';
import {doc,updateDoc} from 'firebase/firestore';
import { dataBase } from '../../firebase';
import { Box } from '@mui/system';
import Alert from '@mui/material/Alert';
import { useEffect } from 'react';
import { CartCon } from '../../context/CartContext';
const CartAmount = (props) => {
  const {loggeduser } = UserAuth();
  const {cartList  } = CartCon()
  const [counter, setCounter] = useState(props.amount)
  const [message, setMessage] = useState('')
  const [showAlert, setshowAlert] = useState("none")
  let myMap = new Map();
  let newCounter
 const updateDbAmount = (newCounter) =>{
    myMap = cartList;
    myMap.forEach((value, key) => {
      if (key === props.itemObj.id) {
       value = newCounter
       myMap.set(props.itemObj.id, value)
      }
    });
    updateMyMap()
 }
  const MinusClick = () => {
    if(showAlert === "show")
    setshowAlert("none")
    if(counter === 1){
      return;
    }
    newCounter = counter - 1;
    updateDbAmount(newCounter);
    setCounter(newCounter)
  }
  const PlusClick = () => {

    if(counter < props.itemObj.amountInStock){
      newCounter = counter + 1;
      updateDbAmount(newCounter);
      setCounter(newCounter);
    }
    else if(props.itemObj.amountInStock === counter || props.itemObj.amountInStock === 1){
      let msg =`Only ${props.itemObj.amountInStock} available in stock.`
      setshowAlert("show")
      setMessage(msg)
    }
  }
  const updateMyMap = () => {
    const docRef = doc(dataBase, "users", loggeduser.uid)
    // Convert the Map to an object
    const myMapObject = {};
    myMap.forEach((value, key) => {
      myMapObject[key] = value;
    });
    const updateField = {cart: myMapObject};
    updateDoc(docRef,updateField)
    .then(() => {
      console.log("Document successfully updated!");
    })
    .catch((error) => {
      console.error("Error updating document: ", error);
    });
   

  }
  useEffect(() => {
    props.UpdateListAmount()
   
  }, [counter])
  
  return (
      <div className="firstRow" style={{display: 'flex'}}>
    <Alert sx={{display:`${showAlert}`}} severity="error">{message}</Alert>
    <Button variant="text" onClick={MinusClick}>-</Button>
    <Box component="span" sx={{ p: 1, border: '1px solid grey' }}>
      {counter}
    </Box>
    <Button variant="text" onClick={PlusClick}>+</Button>
    </div>
  )
}

export default CartAmount