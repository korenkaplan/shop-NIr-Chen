import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemText from '@mui/material/ListItemText';
import Avatar from '@mui/material/Avatar';
import IconButton from '@mui/material/IconButton';
import { Delete } from '@mui/icons-material';
import CartAmount from './CartAmount';
import './delBtn.css';
export const CartItem = (props) => {
  const deleteItemCartItem = () =>{
    props.deleteItem(props.item.id)
  }
  const UpdateListAmount = () =>{
    props.UpdateListAmount()
  }
  return (
    <ListItem
    secondaryAction={
        <div style={{display: 'flex'}}>
      <CartAmount UpdateListAmount ={UpdateListAmount} amount ={props.amount} itemObj = {props.item}/>
      <IconButton className="del_btn" edge="end" aria-label="delete" onClick={deleteItemCartItem}>
        <Delete/>
      </IconButton>
        </div>
    }
  >
    <ListItemAvatar>
      <Avatar>
        <img src ={props.item.imageSrc} alt ='error'/>
      </Avatar>
    </ListItemAvatar>
    <ListItemText
      primary= {props.item.name}
      secondary= {`${props.item.price} $`}
    />
  </ListItem>
  );
}
