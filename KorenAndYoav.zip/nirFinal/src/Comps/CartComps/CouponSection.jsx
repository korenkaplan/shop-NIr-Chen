import React, { useState } from 'react'
import TextField from '@mui/material/TextField';
import { Button } from '@mui/material';
import { UserAuth } from '../../context/AuthContext'
import { dataBase } from "../../firebase";
import Alert from '@mui/material/Alert';
import {CartCon} from '../../context/CartContext'

export const CouponSection = (props) => {
const [colorOfTextfield] = useState("primary")
const [couponCode, setCouponCode] = useState('')
const [message, setMessage] = useState('')
const [showAlert, setshowAlert] = useState("none")
const [alertType, setAlertType] = useState("success")
const {doc,getDoc} = UserAuth()
const {setCouponPrecent} = CartCon()
const UpdateCouponPrecent = (precent) => {
  props.UpdateCouponPrecent(precent)
}
const onChgEvent = (e) =>{
  let text = e.target.value;
  
  if(text.length === 0 && showAlert === "show" )
      setshowAlert("none")

  setCouponCode(text)
}
const ApplyCouponClick = async () =>{
  if(couponCode.length === 0)
  {
   setMessage(`Field can't be empty`)
   setAlertType('error')
   setshowAlert("show")
   return 
  }
  const docRef = doc(dataBase,"coupons",couponCode)
  const docSnap = await getDoc(docRef)
  if(docSnap.exists()){
   // Get amount of precent from coupon and set the state 
   let docData = docSnap.data()
   //UpdateCouponPrecent(Number(docData.precent))
   setCouponPrecent(Number(docData.precent))
   // show alert with success and set message
   setMessage(`Great you get ${docData.precent}% OFF!!..`) // calculate total dicount, total*(precent/100) = total after discount
   setAlertType('success')
   setshowAlert("show")
  }
  else{
   //what to do if coupon is not valid
    // show alert with error and set message
    setMessage(`Invalid coupon code try another`)
    setAlertType('error')
    setshowAlert("show")
  }

 } 
  return (
    <div style={{width:'300px',display: 'flex', marginLeft:'15px'}}>
      <TextField onChange={onChgEvent} color={colorOfTextfield} id="outlined-basic" label="Enter Your Coupon" variant="outlined" />
      <Button onClick={ApplyCouponClick}  sx={{marginLeft:'15px'}} variant="contained">Apply</Button>
      <Alert sx={{display:`${showAlert}`,marginLeft:'10px'}} severity={alertType}>{message}</Alert>
    </div>
  )
}
