import * as React from "react";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import List from "@mui/material/List";
import '../../Css/Cart.css'
import Typography from "@mui/material/Typography";
import { UserAuth } from "../../context/AuthContext";
import { CartItem } from "./CartItem";
import { dataBase } from "../../firebase";
import { doc, updateDoc } from "firebase/firestore";
import { Divider } from "@mui/material";
import { CartCon } from "../../context/CartContext";

const Demo = styled("div")(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
}));
export default function InteractiveList(props) {
  const { loggeduser } = UserAuth();
  const { cartList, setCartList, setTotal, itemObjList, setItemObjList } =
    CartCon();
  const [dense, setDense] = React.useState(false);
  console.log(itemObjList);
  let myMap = new Map();
  let itemsObjUpdated = [];
  let tempArrayOfItems = [];
  let arrayOfItemsUpdated = [];
  const deleteItemAction = (id) => {
    myMap = cartList;
    itemsObjUpdated = itemObjList.filter((item) => item.id !== id);
    myMap.delete(id);
    setCartList(myMap);
    setItemObjList(itemsObjUpdated);
    updateMyMap(myMap);
  };
  const updateMyMap = (myMap) => {
    const docRef = doc(dataBase, "users", loggeduser.uid);
    // Convert the Map to an object
    const myMapObject = {};
    myMap.forEach((value, key) => {
      myMapObject[key] = value;
    });
    const updateField = { cart: myMapObject };
    updateDoc(docRef, updateField)
      .then(() => {
        console.log("Document successfully updated!");
      })
      .catch((error) => {
        console.error("Error updating document: ", error);
      });
    setCartList(myMap);
  };
  const IsContains = (arr, item) => {
    for (let i = 0; i < arr.length; i++) {
      if (arr[i].id === item.id) return true;
    }
    return false;
  };

  const UpdateListAmount = () => {
    arrayOfItemsUpdated = InitCarList();
  };
  const InitCarList = () => {
    let tempList = cartList;
    console.log(tempList);
    let totalAmountUpdated = 0;
    let itemsInCart = itemObjList.map((item1) => {
      let counter;
      let isExists = false;
      tempList.forEach((value, key) => {
        if (key === item1.id && !IsContains(tempArrayOfItems, item1)) {
          tempArrayOfItems.push(item1);
          counter = value;
          totalAmountUpdated += Number(item1.price) * counter; // sum for total amount
          isExists = true;
        }
      });
      if (isExists) {
        return (
          <div>
            <CartItem
              UpdateListAmount={UpdateListAmount}
              deleteItem={deleteItemAction}
              amount={counter}
              item={item1}
              key={item1.id}
            />
            <Divider sx={{ backgroundColor: "blue" }} />
          </div>
        );
      }
    });
    console.log(totalAmountUpdated);
    setTotal(totalAmountUpdated);
    return totalAmountUpdated === 0 ? "Youre cart is empty" : itemsInCart; // show message or list of item if exists
  };
  arrayOfItemsUpdated = InitCarList();
  tempArrayOfItems = [];
  return (
    <Box sx={{ flexGrow: 1, maxWidth: 752, marginLeft: "15px" }}>
      <Typography></Typography>
      <Demo className="linearBG">
        <List dense={dense}>{arrayOfItemsUpdated}</List>
      </Demo>
    </Box>
  );
}
