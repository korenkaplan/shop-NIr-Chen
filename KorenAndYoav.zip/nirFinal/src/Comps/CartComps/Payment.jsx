import React, { useState } from "react";
import { Alert,  Button } from "@mui/material";
import {  dataBase } from "../../firebase";
import {CartCon} from '../../context/CartContext'
import {UserAuth} from '../../context/AuthContext'

import { updateDoc, doc, getDoc } from "firebase/firestore";

//  add coupon and total payment
export const Payment = (props) => {
  const [ setMessage] = useState("");
  const [showAlert, setshowAlert] = useState("none");
  const [setAlertType] = useState("error");
  const {cartList,setCartList,couponPrecent,total} = CartCon()
  const{loggeduser} = UserAuth() 
  let discountPrice = total*(couponPrecent/100)
  let afterDiscount = total - discountPrice
  const UpdateAmountOfItemsInDb = () => {
    // for every item in cart get doc
    cartList.forEach(async (value, key) => {
      const docRef = doc(dataBase, "items", key);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        let docData = docSnap.data()
        let newAmount = Number(docData.amountInStock) - Number(value);
        let updateField = { amountInStock: newAmount };
        updateDoc(docRef, updateField)
          .catch((error) => {
            console.error("Error updating document:", error);
          });
      }
    });

    // when found update amonutInStock - amount
  };
  const UpdateClearList = () => {
    setCartList(new Map())
    updateMyMap()
  }
  const updateMyMap = () => {
    const docRef = doc(dataBase, "users", loggeduser.uid)
    const myMapObject = {};
    const updateField = {cart: myMapObject};
    updateDoc(docRef,updateField)
    .catch((error) => {
      console.error("Error updating document: ", error);
    });
   

  }
  const isDiscount = () => {
    if(couponPrecent > 0) {
      return(
        <div>
           <h4>Discount: {discountPrice}$ ({couponPrecent}%)</h4>
           <h2 style={{borderBottom:"2px solid blue"}}></h2>
           <h4>Total: {afterDiscount}$</h4>
        </div>
      )
  }

      else 
      return(
        <h4></h4>
      )
  }
  const payClickEvent = () => {
      UpdateAmountOfItemsInDb();
      UpdateClearList()
      setMessage("Purchase Successfuly");
      setAlertType("success");
     setshowAlert("show");

    }

    let discountSection = isDiscount()
  return (
   <div style={{width:'300px',marginLeft:'10px', display:'flex', flexDirection:'column',width:'30%'}}>
    <h4>Cost: {total}$</h4>
    <div>{discountSection}</div>
    <Button onClick={payClickEvent} sx={{mt:'10px',mb:'10px', maxWidth:'100px'}} variant="outlined">Pay Now</Button>
    <Alert sx={{display:`${showAlert}`, fontSize:'20px'}}  severity="success">Congratulations your items are on their way</Alert>
   </div>
  );
};
