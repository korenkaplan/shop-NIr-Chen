import React from 'react'
import '../Css/Navbar.css'
import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { UserAuth } from '../context/AuthContext'
function useWindowSize(){
  const [size, SetSize] = useState([window.innerHeight, window.innerWidth]);
  useEffect(() => {
      const Resize = () => {
          SetSize([window.innerHeight, window.innerWidth]);
      };
      window.addEventListener("resize", Resize);
      return () => {
          window.removeEventListener("resize", Resize)
      }
  }, [])
  return size;
}
const Navbar = () => {
  const {name,loggeduser, logout,setName } = UserAuth()
  const [height, width] = useWindowSize();
  const [dropdown, SetDropDown] = useState(<div className="navdropdown"></div>)
  const logoutandSetName = async () =>{
    await logout()
    setName("Guest")
  }
  const ViewNavburger = () => {
    if(dropdown.props.children === undefined)
        {
        SetDropDown
            (
                <div className="navdropdown transformnav">
        <Link className='link linkblack' style={{textDecoration:"none"}}>{signInOutLink()}</Link>
        <Link className='link linkblack' style={{textDecoration:"none", color:'white',fontSize:'25px'}} to="shop">Shop</Link>
        <Link className='link linkblack' style={{textDecoration:"none", color:'white',fontSize:'25px'}} to="cart">Cart</Link>
        <Link className='link linkblack' style={{textDecoration:"none", color:'white',fontSize:'25px'}} to="account">Profile</Link>
                </div>
            )
        }
    else
        {
        SetDropDown
            (
                <div className='navdropdown'></div>
            )
        }
    }
  let signInOutLink = () => {
    if(loggeduser){
      return(
        <Link onClick={logoutandSetName} style={{textDecoration:"none", color:'white',fontSize:'25px'}} to="/">Sign Out</Link>
      )
    }
      else{
        return(
          <Link style={{textDecoration:"none", color:'white',fontSize:'25px'}} to="/">Sign In</Link>
        )
      }
  }
  return (
    <div className='Nav'>
        <div className="logoandtitle" style={{display:'flex', alignItems: "end"}}>
            <h1>Clothing_Store</h1>
            <h4> Hello,{name}</h4>
        </div>
        {
         width > 940 ? (
        <div className="links">
        <Link className='link' style={{textDecoration:"none"}}>{signInOutLink()}</Link>
        <Link className='link' style={{textDecoration:"none", color:'white',fontSize:'25px'}} to="shop">Shop</Link>
        <Link className='link' style={{textDecoration:"none", color:'white',fontSize:'25px'}} to="cart">Cart</Link>
        <Link className='link' style={{textDecoration:"none", color:'white',fontSize:'25px'}} to="account">Profile</Link>
        </div>
        ) : (
            <div className='navburgeranddropdown'>
            <button onClick={() => {ViewNavburger()}} className="navburger">
                <div className="line"></div>
                <div className="line"></div>
                <div className="line"></div>
            </button>
        </div>
        )
        }
    {dropdown}
    </div>
  )
}

export default Navbar