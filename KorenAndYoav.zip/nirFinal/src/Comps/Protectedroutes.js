import React from 'react'
import {Navigate} from 'react-router-dom'
import { UserAuth } from '../context/AuthContext'
const Protectedroutes = ({children}) => {
    const {loggeduser} = UserAuth();
    let adminUid = "kBPHoF5tM0Z0v48UFG5tJZAGnCg2"
    if(loggeduser && loggeduser.uid === adminUid)
    {
      return <Navigate to='/admin' />
    }
    if(!loggeduser) {
        return <Navigate to='/' />
    }
  return children;
}

export default Protectedroutes