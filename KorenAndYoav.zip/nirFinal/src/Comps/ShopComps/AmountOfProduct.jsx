import React, { useState } from 'react'
import { UserAuth } from '../../context/AuthContext'
import Button from '@mui/material/Button';
import {doc,updateDoc} from 'firebase/firestore';
import { dataBase } from '../../firebase';
import { Box } from '@mui/system';
import Alert from '@mui/material/Alert';
import { CartCon } from '../../context/CartContext';
const AmountOfProduct = (props) => {
  const {loggeduser} = UserAuth();
  const {cartList,setCartList, itemObjList, setItemObjList } = CartCon()
  const [counter, setCounter] = useState(1)
  const [message, setMessage] = useState('')
  const [showAlert, setshowAlert] = useState("none")
  const [alertType, setAlertType] = useState("success")
  let myMap = new Map();
  let outofStock = "none";
  let disabled = false
  const MinusClick = () => {
    if(showAlert ==="show")
    setshowAlert("none")
    if(counter === 1){
      return;
    }
    let newCounter = counter - 1;
    setCounter(newCounter)
  }
  const PlusClick = () => {
    if(showAlert === "show")
      setshowAlert("none")
    if(counter < props.itemObj.amountInStock){
      let newCounter = counter + 1;
      setCounter(newCounter);

    }
    else if(props.itemObj.amountInStock === counter || props.itemObj.amountInStock === 1){

      if(alertType !== "error")
      setAlertType("error")
      setshowAlert("show")
      setMessage(`Only ${props.amountInStock} available in stock.`)
    }
   
  }
  const AddToCart = () => {
    myMap = cartList;
    let isExist = false;
    let updateItemObjList = itemObjList
    
    myMap.forEach((value, key, map) => {
      if (key === props.itemObj.id) {
       map.set(key, counter)
       isExist = true
       setMessage(`${props.itemObj.name} Is already in cart, amount updated`)
       setAlertType("warning")
       setshowAlert("show")
      }
    });
    if(!isExist)
    {

      myMap.set(props.itemObj.id, counter)
      updateItemObjList.push(props.itemObj)
      setItemObjList(updateItemObjList)

      setMessage(`${props.itemObj.name} added to cart`)
      if(alertType !== "success")
      setAlertType("success")
      setshowAlert("show")
    }
    updateMyMap()
    setCartList(myMap)
  }
  const updateMyMap = () => {
    const docRef = doc(dataBase, "users", loggeduser.uid)
    // Convert the Map to an object
    const myMapObject = {};
    myMap.forEach((value, key) => {
      myMapObject[key] = value;
    });
    const updateField = {cart: myMapObject};
    updateDoc(docRef,updateField)
    .catch((error) => {
      console.error("Error updating document: ", error);
    });
   

  }
   if(props.isOutOfStock)
   {
    outofStock = "show"
    disabled = true;
   }
  return (
    <div style={{display: 'flex', flexDirection: 'column'}}>
      <div className="firstRow" style={{display: 'flex'}}>
      <Button disabled={disabled} sx={{fontSize:'13px'}}  onClick={AddToCart} variant="outlined">Add To Cart</Button>

    <Button variant="text" onClick={MinusClick}>-</Button>
    <Box component="span" sx={{ p: 1, border: '1px solid grey' }}>
      {counter}
    </Box>
    <Button  variant="text" onClick={PlusClick}>+</Button>
    </div>
    <hr />
    <Alert sx={{display:`${outofStock}`}} severity='error'>Item is out of Stock</Alert>
    <Alert sx={{display:`${showAlert}`}} severity={alertType}>{message}</Alert>
    </div>
  )
}
export default AmountOfProduct