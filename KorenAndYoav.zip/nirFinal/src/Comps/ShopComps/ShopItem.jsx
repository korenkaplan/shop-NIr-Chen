import React from "react";
import AmountOfProduct from "./AmountOfProduct";
import "../../Css/Shop.css";
import Card from "react-bootstrap/Card";
import { Divider } from "@mui/material";
const ShopItem = (props) => {

  return (
    <div>
      <Card
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          width: "17.5rem",
          marginBottom: "5%",
          marginRight: "10px",
        }}
      >
        <Card.Img
          style={{ height: "14rem", width: "14rem" }}
          variant="top"
          src={props.img}
        />
        <Card.Body>
          <Divider sx={{ backgroundColor: "blue", marginBottom: "5px" }} />
          <Card.Title
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-around",
            }}
          >
            <span>{props.name}</span>
            <span style={{ color: "green" }}>{props.price}$</span>
          </Card.Title>
          <Card.Text>{props.description}</Card.Text>
          <div className="btnandamount">
            <AmountOfProduct
              itemObj={props.itemObj}
              amountInStock={props.amountInStock}
              isOutOfStock={props.isOutOfStock}
            />
          </div>
        </Card.Body>
      </Card>
    </div>
  );
};

export default ShopItem;
