import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { updateEmail } from 'firebase/auth';
import { UserAuth } from '../context/AuthContext';
import '../Css/Account.css'
import { TextField } from '@mui/material';
import { doc, updateDoc } from 'firebase/firestore';
import { dataBase } from '../firebase';
import { async } from '@firebase/util';
const Account = () => {
  const {setEmail,email,setName,name,updateLogOut,users,loggeduser, logout, Setloggeduser, updateLoggedFlag} = UserAuth();
  const [newName, setnewName] = useState('')
  const [newEmail,setnewEmail] = useState('')
  const navigate = useNavigate();
  const ChangeEmail = async () => {
let newUser = loggeduser;
await updateEmail(newUser,newEmail)
setEmail(newEmail)
  .then(function() {
    console.log("Email updated successfully");
  })
  .catch(function(error) {
    console.log("Error updating email: ", error);
  });
  }
  const ChangeName = async () => {
    const docRef = doc(dataBase, "users", loggeduser.uid)
    const updateField = {
      name: newName
    }
    await updateDoc(docRef, updateField);
    setName(newName)
  }

  return (
    <div className='detailscon'>
      <div className="form">
    <h1 className='text-2xl font-bold py-4'>My Account</h1>
    <div className="emailcon">
    <div className='nameandtextfield'>
    <p>Email: {loggeduser && loggeduser.email}</p>
    <div className="flexwrap">
    <span className="editname">Edit Email: </span>
    <TextField className='textfield' onChange={(e) => setnewEmail(e.target.value)} id="outlined-basic" label="Name" variant="outlined" />
    </div>
    </div>
    <button className='saveChangesBtn' onClick={ChangeEmail}>Save Changes</button>
    </div>
   <hr/>
    <div className="emailcon">
      <div className='nameandtextfield'>
    <p>Name: {loggeduser && name}</p>  
    <div className="flexwrap">
      <span className="editname">Edit Name: </span>
    <TextField style={{color: 'white'}} className='textfield' onChange={(e) => setnewName(e.target.value)} id="outlined-basic" label="Email" variant="outlined" />
    </div>
    </div>
    <button className='saveChangesBtn' onClick={ChangeName} >Save Changes</button>
    </div>
    </div>
    </div>
  )
}

export default Account