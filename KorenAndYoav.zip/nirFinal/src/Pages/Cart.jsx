import React from "react";
import '../Css/Cart.css'
import { CartCon } from "../context/CartContext";
import { Payment } from "../Comps/CartComps/Payment";
import { CouponSection } from "../Comps/CartComps/CouponSection";
import InteractiveList from "../Comps/CartComps/InteractiveList";
const Cart = () => {
  const { cartList, setCartList } = CartCon();

  setCartList(cartList);
  return (
    <div className="cartpage">
      <div className="cartform">
      <InteractiveList />
      
      <br />
      <div className="couponandpayment">
      <CouponSection/>
      <br />
      <Payment />
      </div>
      </div>
    </div>
  );
};

export default Cart;
