import React, { useEffect } from "react";
import "../Css/Shop.css";
import ShopItem from "../Comps/ShopComps/ShopItem";
import { UserAuth } from "../context/AuthContext";
import { CartCon } from "../context/CartContext";
import { dataBase } from "../firebase";
import { collection,getDocs } from "firebase/firestore";
const Shop = () => {
  const { items,setName, loggeduser,getDoc,doc, setItems } = UserAuth();
  const {  setCartList,setItemObjList} = CartCon();
useEffect(() => {
  InitName()
  UpdateItemAmountFromDb()
  InitCart()
}, [])
const InitName = async () => {
  const docRef = doc(dataBase, "users", loggeduser.uid)
      const docSnap = await getDoc(docRef)
      if(docSnap.exists()){
        let docData = docSnap.data()
        setName(docData.name)
      }
}
const InitItemsObjectList = (crtFromDb) =>{
  let newItemList = []
  Object.keys(crtFromDb).forEach((key) => {
    for (let i = 0; i < items.length; i++)
    {
      if(items[i].id === key)
      {
        newItemList.push(items[i])
      }
    }
  });
  console.log(newItemList);
  setItemObjList(newItemList)
}
  const InitCart = async () => {
    const docRef = doc(dataBase, "users", loggeduser.uid)
    const docSnap = await getDoc(docRef)
    if(docSnap.exists()){
      let docData = docSnap.data()
    InitItemsObjectList(docData.cart)
    const myMap = new Map();
     Object.keys(docData.cart).forEach((key) => {
      myMap.set(key, docData.cart[key]);
    });
    setCartList(myMap)
  };
}

  let itemsInShop = items.map((item) => {
 let isOutOfStock = item.amountInStock <= 0
    return (
      <ShopItem
        id={item.id}
        description={item.description}
        price={item.price}
        category={item.category}
        img={item.imageSrc}
        key={item.id}
        amountInStock={item.amountInStock}
        itemObj={item}
        isIncart={false}
        name={item.name}
        isOutOfStock={isOutOfStock}
      />
    );
  });
  const UpdateItemAmountFromDb = async ()=>{
    const itemsCollectionRef = collection(dataBase, "items");
    const itemsdata = await getDocs(itemsCollectionRef);
    setItems(itemsdata.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
  }
  return (
    <div className="Items_Con">
      {itemsInShop}
    </div>
  );
};

export default Shop;
