import { createContext, useContext, useState, useEffect } from "react";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,

} from "firebase/auth";
import { auth } from "../firebase";
import { dataBase } from "../firebase";
import { storage } from "../firebase";
import {
  collection,
  getDocs,
  getDoc,
  updateDoc,
  doc,
  setDoc,
} from "firebase/firestore";
const UserContext = createContext();

export const AuthContextProvider = ({ children }) => {
  useEffect(() => {
    const getData = async () => {
      const usersdata = await getDocs(usersCollectionRef);
      const itemsdata = await getDocs(itemsCollectionRef);
      setUsers(usersdata.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
      setItems(itemsdata.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
    };
    getData();
  }, []);
  const itemsCollectionRef = collection(dataBase, "items");
  const usersCollectionRef = collection(dataBase, "users");
  const [loggeduser, Setloggeduser] = useState(null);
  const [loggedUserRef, setloggedUserRef] = useState();
  const [users, setUsers] = useState([]);
  const [items, setItems] = useState([]);
  const [itemsObjInCart, setItemsObjInCart] = useState([]);
  const [name, setName] = useState('Guest');
  const [email,setEmail] = useState('');
  
  auth.onAuthStateChanged((user) => {
    Setloggeduser(user);
  });
  const createUser = async (name,email, password) => {
    try{
      await createUserWithEmailAndPassword(auth, email, password);
      await addUserDoc(name,email, password)
      return true;
    }
    catch(err){
      alert(err.message);
      return false
    }
  
  };
  const updateLogOut = async (id) => {
    const userDoc = doc(dataBase, "users", id);
    const updateField = { islogged: false };
    return await updateDoc(userDoc, updateField);
  };
  const signIn = async (email, password) => {
    return await signInWithEmailAndPassword(auth, email, password);
  };
  const logout = () => {
    return signOut(auth);
  };
  const addUserDoc = async (name, email, password) => {
    let User = await signInWithEmailAndPassword(auth, email, password);
    let userid = User.user.uid;
    await signOut(auth);
    await setDoc(doc(dataBase, "users", userid), 
    {
      cart: {},
      name: name
    }
    )
  }
  return (
    <UserContext.Provider
      value={{
        name, setName,email,setEmail,addUserDoc,storage,
        itemsObjInCart,
        setItemsObjInCart,
        setloggedUserRef,
        loggedUserRef,
        usersCollectionRef,
        setItems,
        loggeduser,
        Setloggeduser,
        getDoc,
        setDoc,
        doc,
        updateLogOut,
        Setloggeduser,
        loggeduser,
        createUser,
        logout,
        signIn,
        items,
        users,
        itemsCollectionRef
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const UserAuth = () => {
  return useContext(UserContext);
};
