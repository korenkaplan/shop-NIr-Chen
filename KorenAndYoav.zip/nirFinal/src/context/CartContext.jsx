import { createContext, useContext, useState } from "react";
const CartContext = createContext();

export const CartContextProvider = ({children}) => {
  const [total, setTotal] = useState(0)
  const [cartList, setCartList] = useState(new Map())
  const [couponPrecent, setCouponPrecent] = useState(0)
  const [itemObjList, setItemObjList] = useState([]);
  

  return (
    <CartContext.Provider
    value={{itemObjList, setItemObjList,total, setTotal,cartList, setCartList, couponPrecent, setCouponPrecent }}
    >
        {children}
    </CartContext.Provider>
  )
}
export const CartCon = () =>{
    return useContext(CartContext)
} 
