// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import {getFirestore} from "firebase/firestore"
import { getStorage } from "firebase/storage";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBeqXlQIhJB0v6t2N-_zR6RYgKrVRJzPTQ",
  authDomain: "fb-tutpractice.firebaseapp.com",
  projectId: "fb-tutpractice",
  storageBucket: "fb-tutpractice.appspot.com",
  messagingSenderId: "783531894360",
  appId: "1:783531894360:web:35da767961c58104500c2d"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app)
export const dataBase = getFirestore(app)
export const storage = getStorage(app)
